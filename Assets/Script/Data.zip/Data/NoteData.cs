using UnityEngine;

public enum NoteData
{
    C, Cs, D, Ds, E, F, Fs, G, Gs, A, As, B
}